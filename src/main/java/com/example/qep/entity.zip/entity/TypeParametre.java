package com.example.qep.entity;

public enum TypeParametre {
    MICRO,
    PHYSICO
}
