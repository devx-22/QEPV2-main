package com.example.qep.repository;

import com.example.qep.entity.Unite;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UniteRepository extends JpaRepository<Unite, Long> {}
