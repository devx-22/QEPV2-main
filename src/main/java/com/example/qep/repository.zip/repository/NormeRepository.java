package com.example.qep.repository;

import com.example.qep.entity.Norme;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NormeRepository extends JpaRepository<Norme, Long> {
}
