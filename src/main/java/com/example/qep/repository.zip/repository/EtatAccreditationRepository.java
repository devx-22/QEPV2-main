package com.example.qep.repository;

import com.example.qep.entity.EtatAccreditation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EtatAccreditationRepository extends JpaRepository<EtatAccreditation, Long> {
}
