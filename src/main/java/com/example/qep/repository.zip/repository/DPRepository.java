package com.example.qep.repository;

import com.example.qep.entity.DP;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DPRepository extends JpaRepository<DP, Long> {}
