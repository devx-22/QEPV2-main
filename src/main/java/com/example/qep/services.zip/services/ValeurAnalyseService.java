package com.example.qep.services;

import com.example.qep.entity.Analyse;
import com.example.qep.repository.AnalyseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ValeurAnalyseService {

    @Autowired
    private AnalyseRepository repository;

    public List<Analyse> findAll() {
        return repository.findAll();
    }

    public Optional<Analyse> findById(Long id) {
        return repository.findById(id);
    }

    public Analyse save(Analyse valeurAnalyse) {
        return repository.save(valeurAnalyse);
    }

    public void deleteById(Long id) {
        repository.deleteById(id);
    }

    public List<Analyse> saveAll(List<Analyse> valeurs) {
        return repository.saveAll(valeurs);
    }
}
